const router = require('express').Router();
const Banner = require('../model/banner');
const Query = require('../model/query');
 const UserReg = require('../model/usersreg');
 const multer =require('multer');//module

 //storeage 

 const stroage =multer.diskStorage({
destination : function(req,file,callback){
    callback(null,'./public/upload');
},
//  add prefix to file
filename : function(req,file,callback){
    callback(null, Date.now()+file.originalname);
},

 });

 //upload

 const upload =multer({
     storage:stroage,
     limits: { fileSize : 1024*1024*4}, //4mb
 });
 

 let ab;

function checklogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/login')
    }
};

function hnadleRoles(req,res,next){
    if(ab.role !== 'public'){
        next()
    }else{
        res.send("you dont have rights to see the containe of this page");
    }
}


router.get('/',checklogin,hnadleRoles,async (req, res) => {
    const banner = await Banner.findOne();
    res.render('index', {banner});
})

router.get('/banner',async (req, res) => {
    const banner = await Banner.findOne();
    res.render('banner.ejs', { banner });
});

router.post('/querydata', async (req, res) => {
    const { name, email, query } = req.body;
    const status = 'unread'
    const queryRecord = new Query({ name: name, email: email, query: query, status: status });
    await queryRecord.save();

});
router.get('/registraion', (req, res) => {
    res.render('registration.ejs')
});
router.post('/regdata', async(req, res) => {
    const {username,pass}=req.body
     const status= 'suspended'
     const role = 'public'
    const regRecord = new UserReg({username:username,password:pass,status:status,role:role})
    await regRecord.save();

});

router.get('/login',(req,res)=>{
    res.render('login.ejs');
})

router.post('/logincheck',async(req,res)=>{
   const{username,pass}=req.body;
  const userrecord= await UserReg.findOne({username:username});
  console.log(userrecord);
   if(userrecord !==null){
       if(userrecord.password ==pass){
        if(userrecord.status =='active'){
       console.log('correct details');
       req.session.isAuth =true;
        ab=req.session;
        ab.role =userrecord.role;
        console.log(ab.role);
       res.redirect('/');

        }else{
            res.redirect('/login'); 
        }
       }else{
        res.redirect('/login');
       }
   }else{
       res.redirect('/login');
   }
});

router.get('/logout',(req,res)=>{
    req.session.destroy();
    res.redirect('login');
})

router.get('/image',(req,res)=>{
 res.render('imageform.ejs')
});

router.post('/imagerecord',upload.single('img'),(req,res)=>{
    console.log(req.file);

})



module.exports = router;