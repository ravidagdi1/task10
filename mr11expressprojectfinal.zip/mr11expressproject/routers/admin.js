const router = require('express').Router()//module
const Admin = require('../model/adminreg');
const Banner = require('../model/banner');
const bcrypt = require('bcrypt');
const Query = require('../model/query');
const UserReg = require('../model/usersreg');
const Parking=require('../model/parking');
const multer =require('multer');//module

 //storeage 

 const stroage =multer.diskStorage({
destination : function(req,file,callback){
    callback(null,'./public/upload');
},
//  add prefix to file
filename : function(req,file,callback){
    callback(null, Date.now()+file.originalname);
},

 });

 //upload

 const upload =multer({
     storage:stroage,
     limits: { fileSize : 1024*1024*4}, //4mb
 });
 



function checkLogin(req, res, next) {
    if (req.session.isAuth) {
        next()
    } else {
        res.redirect('/admin/');
    }
}

router.get('/', (req, res) => {
    res.render('admin/login.ejs');
})

router.get('/dashboard', checkLogin, (req, res) => {
    res.render('admin/dashboard');
})

router.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/admin/');
})

router.post('/', async (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    const admin = await Admin.findOne({ username: username });
    if (admin !== null) {
        const comparedpassword = await bcrypt.compare(password, admin.password)
        //console.log(comparedpassword);
        //console.log(admin.password)
        if (comparedpassword) {
            req.session.isAuth = true;
            res.redirect('/admin/dashboard');
        } else {
            res.redirect('/admin/');
        }
    } else {
        res.redirect('/admin/');
    }
});

router.get('/banner', async (req, res) => {
    const bannerRecord = await Banner.findOne()
    res.render('admin/banner.ejs', { bannerRecord: bannerRecord })
})



//////test url to enter values in database
router.get('/test', async (req, res) => {
    const username = 'ravi'
    let password = 'abc';
    //let ldesc= 'dgdfhgdg'
    const hashedPassword = await bcrypt.hash(password, 10);
    //console.log(hashedPassword);
    const admin = new Admin({ username: username, password: hashedPassword })
    await admin.save();

})

router.get('/bannerform/:id', async (req, res) => {
    const id = req.params.id;
    const bannerrecord = await Banner.findById(id)
    res.render('admin/bannerform.ejs', { bannerrecord });
})

router.post('/bannerupdate/:id',upload.single('img'), async (req, res) => {
    const id = req.params.id;
    const title = req.body.title;
    const desc = req.body.desc
    const ldesc = req.body.ldesc
    const status = 'unread'
    if(req.file){
    await Banner.findByIdAndUpdate(id, { title: title, desc: desc, ldesc: ldesc,img:req.file.filename });
    }
    else{
        await Banner.findByIdAndUpdate(id, { title: title, desc: desc, ldesc: ldesc }); 
    }
    res.redirect('/admin/banner');

});

router.get('/query', async (req, res) => {
    const queryRecords = await Query.find();
    //console.log(queryRecords)
    res.render('admin/query.ejs', { queryRecords: queryRecords, title: 'query' })
})

router.get('/queryupdate/:id', async (req, res) => {
    const { id } = req.params
    const queryRecord = await Query.findById(id)
    console.log(queryRecord);
    let a = null;
    if (queryRecord.status == 'unread') {
        a = 'read'
    } else {
        a = 'unread'
    }
    await Query.findByIdAndUpdate(id, { name: queryRecord.name, email: queryRecord.email, query: queryRecord.query, status: a })
    res.redirect('/admin/query');

});
router.post('/querySearch', async (req, res) => {
    const { search } = req.body;
    const searchRecords = await Query.find({ status: search });
    res.render('admin/query.ejs', { queryRecords: searchRecords, title: 'query' })
});

router.get('/usermanage', async (req, res) => {
    const userdata = await UserReg.find()
    res.render('admin/usermanage.ejs', { queryRecords: userdata, title: 'User Managemenet' })
});
router.get('/statuschange/:id', async (req, res) => {
    const id = req.params.id;
    console.log(id);
    const userRecord = await UserReg.findById(id);
    console.log(userRecord);
    let status =null;
    if(userRecord.status =='suspended'){
        status ='active'
    }else{
        status ='suspended'
    }
       await UserReg.findByIdAndUpdate(id,{username:userRecord.username,password:userRecord.password,status:status,role:userRecord.role});
       res.redirect('/admin/usermanage');

});

router.get('/rolechange/:id',async(req,res)=>{
    const id = req.params.id
    const regRecord =  await UserReg.findById(id);
    console.log(regRecord);
    let role =null;
    if(regRecord.role == 'public'){
        role='pvt'
    }else{
        role='public'
    }

   await UserReg.findByIdAndUpdate(id,{username:regRecord.username,password:regRecord.password,status:regRecord.status,role:role})
        res.redirect('/admin/usermanage');
});
//////////////////////////// parking system

router.get('/parking',(req,res)=>{
    res.render('admin/parkingform.ejs');
   
  

})

router.post('/parkingRecord',async(req,res)=>{
    const{vnumber,vtype,entertime}=req.body;
    const exitTime =0;
    const amount=0;
    const status ='IN'
   const parkingRecord= new Parking({vnumber:vnumber,vtype:vtype,enterTime:entertime,exitTime:exitTime,amount:amount,status:status});
    await parkingRecord.save();
    res.redirect('/admin/parkingfetch');

});

router.get('/parkingfetch',async(req,res)=>{
   const parkingRecords= await Parking.find();
   res.render('admin/parkingfetch.ejs',{parkingRecords})
});

router.get('/parkingupdate/:id',async(req,res)=>{
    const id = req.params.id;
    //console.log(id)
  const parkingRecord =await Parking.findById(id);
    res.render('admin/parkingupdate.ejs',{parkingRecord})

});

router.post('/parkupdate/:id',async(req,res)=>{
    const{exit}=req.body;
    const id =req.params.id;
     const parkRecord =await Parking.findById(id);
     console.log(parkRecord);
     let finalAmount =0;
     if(parkRecord.vtype == 'twow'){
      finalAmount = (exit-parkRecord.enterTime)*20
     }
     else if(parkRecord.vtype == 'threew'){
        finalAmount = (exit-parkRecord.enterTime)*40
     }
     else if(parkRecord.vtype == 'fourw'){
        finalAmount = (exit-parkRecord.enterTime)*100
     }
     await Parking.findByIdAndUpdate(id,{exitTime:exit, amount:finalAmount,status:'out'})
     res.redirect('/admin/parkingfetch');

});

module.exports = router;